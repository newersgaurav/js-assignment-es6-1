function question1(){
	var arr=[3,62,234,7,23,74,23,76,92];
	console.log(arr);

	var arr2=arr.filter(e=>{
	  if(e>70)
	    return e;
	});
	console.log("array elements greater than 70 " + arr2);
}

function question2(){
	let list=document.querySelectorAll("li")
	var arr1=[]

	for(let a=0;a<list.length;a++){
	  arr1.push(list[a]);
	};
	return arr1;
}

function question2_1(){
	var arr1 = question2();
	console.log(arr1); 
}

function question2_2(){
	var arr1 = question2();
	var arr2=arr1.filter(value=>{
	  if (value.innerHTML.split(" ")[0] == "Flexbox")
                return value;
	});
	console.log(arr2);
}

function question2_3(){

	var array = question2();

	var list = array.map(element => {
            return element.getAttribute("data-time");
        });
    console.log(list);

}

function question2_4(){

	var array = question2();
	var second = array.map(element=>{
            return parseInt(element.getAttribute("data-time").split(":")[1]);
        })
        console.log(second);
}

function question2_5(){

	var array = question2();
	var list = array.map(element => {
            return element.getAttribute("data-time");
        });
	var sumSecond = list.reduce((accumulator,ele)=>{
            let sec = parseInt(ele.split(":")[1]);
            let min = parseInt(ele.split(":")[0])*60;
            return accumulator+sec+min;
        },0)
        console.log("second sum: ", sumSecond);
        var sumHour = Math.round(sumSecond/3600);
        sumSecond = sumSecond%3600;
        var sumMinute = Math.round(sumSecond/60);
        sumSecond = Math.round(sumSecond%60);
        console.log(`Total Time : ${sumHour}:${sumMinute}:${sumSecond}`);
}

function question3(){
	 const song = {
            name: 'Dying to live',
            artist: 'Tupac',
            featuring: 'Biggie Smalls'
        };
        document.querySelector("#answer-3").innerText = `${song.name} - ${song.artist}
		(Featuring ${song.featuring})`
        console.log(`${song.name} - ${song.artist}
 		   (Featuring ${song.featuring})`);
}

function question4(){
	const user = {
            firstName: "Sahil",
            lastName: "Dua",
            Address: {
                Line1: "address line 1",
                Line2: "address line 2",
                State: "Delhi",
                Pin: 110085,
                Country: "India",
                City: "New Delhi"
            },
            phoneNo: 9999999999
        }
        let{Line1:addressLine1, Line2, State, Pin, Country, City} = user.Address
        
        var addr = `
line1 = ${addressLine1}
line2 = ${Line2}
state = ${State}
pin = ${Pin}
country = ${Country}
city = ${City}`
        document.querySelector("#answer-4").innerText = addr;
        console.log(addr);
}